import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestorEmpleados {
    private List<Empleado> empleados;

    public GestorEmpleados() {
        this.empleados = new ArrayList<>();
    }

    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public void mostrarEmpleados() {
        for (Empleado empleado : empleados) {
            empleado.imprimirInformacion();
        }
    }

    public void agregarEmpleadoPorConsola(Scanner scanner) {
        System.out.print("Ingrese el nombre del empleado: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la edad del empleado: ");
        int edad = scanner.nextInt();
        System.out.print("Ingrese el salario del empleado: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); // Consumir la nueva línea pendiente

        Empleado empleado = new Empleado(nombre, edad, salario);
        agregarEmpleado(empleado);
    }
}
